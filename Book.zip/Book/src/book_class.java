public class book_class {
    private String title;
    private String author;
    private double price;

    public book_class(String title, String author, double price, String string, String string2) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

	public String getCategory() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getCondition() {
		// TODO Auto-generated method stub
		return null;
	}
}
